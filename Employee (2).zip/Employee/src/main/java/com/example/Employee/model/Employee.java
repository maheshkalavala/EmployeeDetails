package com.example.Employee.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="emp_details")
public class Employee {
	
	@Id
	@GeneratedValue
	private Integer empId;

	private String firstName;
	
	
	private String lastName;
	
	private String email;
	
	private String phoneNo;
	
	private String dataOfJoining;
	
	private Double salary;
	
	private Double yearlyTax;
	
	

	public Double getYearlyTax() {
		return yearlyTax;
	}

	public void setYearlyTax(Double yearlyTax) {
		this.yearlyTax = yearlyTax;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getDataOfJoining() {
		return dataOfJoining;
	}

	public void setDataOfJoining(String dataOfJoining) {
		this.dataOfJoining = dataOfJoining;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	
	
	

}
