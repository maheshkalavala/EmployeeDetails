package com.example.Employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Employee.Data.EmployeeDto;
import com.example.Employee.Data.ResponseData;
import com.example.Employee.api.IEmployee;

@RestController
public class EmployeeConroller {
	
@Autowired
private IEmployee iEmployee;

@PostMapping("/save/employeeDetails")
public ResponseData saveEmployeeDetails(@RequestBody List<EmployeeDto> employeeDto) {
	
	return iEmployee.saveEmployeeDetails(employeeDto);
}

@GetMapping("/get/employeeDetails")
public List<EmployeeDto> getEmployeeDetails() {

	return iEmployee.getEmployeeDetails();
}
}

