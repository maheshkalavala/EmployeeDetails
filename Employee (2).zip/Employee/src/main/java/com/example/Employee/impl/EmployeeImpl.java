package com.example.Employee.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Employee.Data.EmployeeDto;
import com.example.Employee.Data.ResponseData;
import com.example.Employee.api.IEmployee;
import com.example.Employee.model.Employee;
import com.example.Employee.repository.EmployeeRepo;

@Service
public class EmployeeImpl implements IEmployee {

	@Autowired
	EmployeeRepo employeeRepo;

	@Override
	public ResponseData saveEmployeeDetails(List<EmployeeDto> employeeDto) {

		ArrayList<Employee> empList=new ArrayList<Employee>();

		for(EmployeeDto employeeDetails:employeeDto)
		{
			Employee emp=new Employee();
			BeanUtils.copyProperties(emp,employeeDetails);
			empList.add(emp);
		}
		employeeRepo.saveAll(empList);
		return new ResponseData("Employee Details Saved Successfull",200);
	}

	@Override
	public List<EmployeeDto> getEmployeeDetails() {

		ArrayList<EmployeeDto> employeesList=new ArrayList<EmployeeDto>();

		List<Employee> empList=employeeRepo.findAll();

		Double tax;
		for(Employee empDetails:empList)
		{
			EmployeeDto emp=new EmployeeDto();
			emp.setEmpId(empDetails.getEmpId());
			emp.setFirstName(empDetails.getFirstName());
			emp.setLastName(empDetails.getLastName());

			String a[]=empDetails.getDataOfJoining().split("-");

			Integer totalMonths=12-Integer.parseInt(a[1]);

			emp.setSalary(empDetails.getSalary()*totalMonths);

			double yearSal=empDetails.getSalary()*totalMonths;

			if(yearSal<=250000)
			{
				emp.setYearlyTax(0.0);
			}
			else if (yearSal>250000 && yearSal<=500000) {

				tax=yearSal*5/100;

				emp.setYearlyTax(tax);
			}
			else if (yearSal>500000 && yearSal<=1000000) {

				tax=yearSal*10/100;

				emp.setYearlyTax(tax);
			}
			else
			{
				tax=yearSal*20/100;

				emp.setYearlyTax(tax);
			}

			employeesList.add(emp);
		}
		return employeesList;
	}

}
