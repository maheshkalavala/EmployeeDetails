package com.example.Employee.api;

import java.util.List;

import com.example.Employee.Data.EmployeeDto;
import com.example.Employee.Data.ResponseData;

public interface IEmployee {
	
	ResponseData saveEmployeeDetails(List<EmployeeDto> employeeDto);
	
	List<EmployeeDto> getEmployeeDetails();

}
